package com.example.springboot.myFirstWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
